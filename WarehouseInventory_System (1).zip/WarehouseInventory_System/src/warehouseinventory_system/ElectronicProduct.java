package warehouseinventory_system;

// Electronic product.



public class ElectronicProduct extends Product {

    private String brand;
    private int warrantyYears;

    // empty constructor
    public ElectronicProduct() {
        this(0, "", 0.0, "", 0, 0, null, "", 0);
    }

    /**
     * Full constructor
     * @param itemId item id
     * @param itemName item name
     * @param unitPrice unit price
     * @param categoryCode category code
     * @param quantity product quantity
     * @param reorderLevel reorder level
     * @param supplier supplier object
     * @param brand product brand
     * @param warrantyYears warranty years
     */
    public ElectronicProduct(int itemId, String itemName, double unitPrice, String categoryCode,
                             int quantity, int reorderLevel, Supplier supplier,
                             String brand, int warrantyYears) {
        super(itemId, itemName, unitPrice, categoryCode, quantity, reorderLevel, supplier);
        setBrand(brand);
        setWarrantyYears(warrantyYears);
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand.trim();
    }

    public int getWarrantyYears() {
        return warrantyYears;
    }

    public void setWarrantyYears(int warrantyYears) {
        if (warrantyYears < 0) {
            throw new IllegalArgumentException("Warranty years cannot be negative");
        }
        this.warrantyYears = warrantyYears;
    }

    /**
     * Calculates value with tax.
     * @return value after tax
     */
    @Override
    public double calculateValue() {
        return super.calculateValue() + (super.calculateValue() * TAX_RATE);
    }

    @Override
    public void showDetails() {
        System.out.println(toString());
    }

    public boolean hasLongWarranty() {
        return getWarrantyYears() >= 2;
    }

    @Override
    public String toString() {
        return String.format("%s%nBrand: %s%nWarranty Years: %d%nLong Warranty: %b",
                super.toString(), getBrand(), getWarrantyYears(), hasLongWarranty());
    }
}



