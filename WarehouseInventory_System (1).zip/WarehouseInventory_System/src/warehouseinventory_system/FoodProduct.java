
package warehouseinventory_system;

// Food product.
public class FoodProduct extends Product {

    private String expiryDate;
    private double storageTemp;

    // empty constructor
    public FoodProduct() {
        this(0, "", 0.0, "", 0, 0, null, "", 0.0);
    }

    /**
     * Full constructor
     * @param itemId item id
     * @param itemName item name
     * @param unitPrice unit price
     * @param categoryCode category code
     * @param quantity product quantity
     * @param reorderLevel reorder level
     * @param supplier supplier object
     * @param expiryDate expiry date
     * @param storageTemp storage temperature
     */
    public FoodProduct(int itemId, String itemName, double unitPrice, String categoryCode,
                       int quantity, int reorderLevel, Supplier supplier,
                       String expiryDate, double storageTemp) {
        super(itemId, itemName, unitPrice, categoryCode, quantity, reorderLevel, supplier);
        setExpiryDate(expiryDate);
        setStorageTemp(storageTemp);
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate.trim();
    }

    public double getStorageTemp() {
        return storageTemp;
    }

    public void setStorageTemp(double storageTemp) {
        this.storageTemp = storageTemp;
    }

    /**
     * Calculates food product value.
     * @return product value
     */
    @Override
    public double calculateValue() {
        return super.calculateValue();
    }

    @Override
    public void showDetails() {
        System.out.println(toString());
    }

    public boolean needsColdStorage() {
        return getStorageTemp() < 10;
    }

    @Override
    public String toString() {
        return String.format("%s%nExpiry Date: %s%nStorage Temp: %.2f%nCold Storage: %b",
                super.toString(), getExpiryDate(), getStorageTemp(), needsColdStorage());
    }
}
