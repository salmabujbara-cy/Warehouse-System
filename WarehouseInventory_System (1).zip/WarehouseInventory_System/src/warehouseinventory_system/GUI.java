package warehouseinventory_system;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

// Simple JavaFX GUI.
public class GUI extends Application {

    @Override
    public void start(Stage primaryStage) {

        Label title = new Label("Warehouse Inventory System");

        Label idLabel = new Label("Item ID:");
        TextField idField = new TextField();

        Label nameLabel = new Label("Item Name:");
        TextField nameField = new TextField();

        Label priceLabel = new Label("Unit Price:");
        TextField priceField = new TextField();

        Button addButton = new Button("Add");
        Button showButton = new Button("Show");

        TextArea outputArea = new TextArea();
        outputArea.setEditable(false);

        GridPane pane = new GridPane();
        pane.setHgap(10);
        pane.setVgap(10);
        pane.setStyle("-fx-background-color: #F4F4F4; -fx-padding: 15;");

        pane.add(title, 0, 0, 2, 1);
        pane.add(idLabel, 0, 1);
        pane.add(idField, 1, 1);
        pane.add(nameLabel, 0, 2);
        pane.add(nameField, 1, 2);
        pane.add(priceLabel, 0, 3);
        pane.add(priceField, 1, 3);
        pane.add(addButton, 0, 4);
        pane.add(showButton, 1, 4);
        pane.add(outputArea, 0, 5, 2, 1);

        addButton.setOnAction(e -> {
            try {
                int id = Integer.parseInt(idField.getText().trim());
                String name = nameField.getText().trim();
                double price = Double.parseDouble(priceField.getText().trim());

                Supplier supplier = new Supplier("S999", "GUI Supplier", "0500000000", "Riyadh");

                Product product = new Product(id, name, price, "GUI", 1, 1, supplier);
                Main.system.addProduct(product);

                outputArea.setText("Product added successfully.");

                idField.clear();
                nameField.clear();
                priceField.clear();

            } catch (NumberFormatException ex) {
                outputArea.setText("Error: Enter valid numbers.");
            } catch (IllegalArgumentException ex) {
                outputArea.setText("Error: " + ex.getMessage());
            }
        });

        showButton.setOnAction(e -> {
            String text = "";

            for (int i = 0; i < Main.system.getProducts().size(); i++) {
                text += Main.system.getProducts().get(i).toString();
                text += "\n------------------\n";
            }

            outputArea.setText(text);
        });

        Scene scene = new Scene(pane, 400, 500);
        primaryStage.setTitle("Warehouse Inventory GUI");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}