package warehouseinventory_system;
//abstract class
public abstract class Item implements Sellable {

    private  int itemId;
    private String itemName;
    private double unitPrice;
    private final String CATEGORY_CODE;
    private static int totalItems;

    public Item() {
        this(0, "", 0.0, "");
    }

    public Item(int itemId, String itemName, double unitPrice, String CATEGORY_CODE) {
        this.itemId = itemId;
        setItemName(itemName);
        setUnitPrice(unitPrice);
        this.CATEGORY_CODE = CATEGORY_CODE;
        totalItems++;
    }

    public int getItemId() {
        return itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName.trim();
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        if (unitPrice < 0) {
            throw new IllegalArgumentException("Unit price cannot be negative");
        }
        this.unitPrice = unitPrice;
    }

    public String getCategoryCode() {
        return CATEGORY_CODE;
    }

   
    public static int getTotalItems() {
        return totalItems;
    }

    public static void setTotalItems(int totalItems) {
        Item.totalItems = totalItems;
    }

    @Override
    public abstract double calculateValue();

    @Override
    public abstract boolean isAvailable();

    public abstract void showDetails();

    @Override
    public String toString() {
        return String.format("Item ID: %d%nItem Name: %s%nUnit Price: %.2f%nCategory Code: %s",
                getItemId(), getItemName(), getUnitPrice(), getCategoryCode());
    }
}