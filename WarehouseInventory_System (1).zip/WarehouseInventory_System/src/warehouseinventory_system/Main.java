package warehouseinventory_system;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {

    public static WarehouseInventoryManager system = new WarehouseInventoryManager();
    public static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        int choice = 0;
        fillList();

        System.out.println("**** Welcome To Warehouse Inventory System ****");

        do {
            try {
                menu();
                choice = Integer.parseInt(input.nextLine().trim());

                switch (choice) {
                    case 1: addProduct(); break;
                    case 2: system.displayAllProducts(); break;
                    case 3: system.displayAllWarehouses(); break;
                    case 4: appendProductToWarehouse(); break;
                    case 5: removeProductFromWarehouse(); break;
                    case 6: searchProductInWarehouse(); break;
                    case 7: displayWarehouseProducts(); break;
                    case 8: writeText(); break;
                    case 9: readText(); break;
                    case 10: showLongWarrantyProducts(); break;
                    case 11: openGUI(); break;
                    case 12: System.out.println("Thank you!"); break;
                    default: System.out.println("Invalid option!");
                }

            } catch (NumberFormatException ex) {
                System.err.println("Invalid input");
            } catch (NullPointerException ex) {
                System.err.println(ex);
            } catch (ClassCastException ex) {
                System.err.println(ex);
            } catch (ArrayIndexOutOfBoundsException ex) {
                System.err.println(ex);
            } catch (Exception ex) {
                System.err.println(ex);
            }

        } while (choice != 12);
    }

    public static void menu() {
        System.out.print(
                "\n1.  Add product.\n"
              + "2.  Display all products.\n"
              + "3.  Display warehouses.\n"
              + "4.  Add product to warehouse array.\n"
              + "5.  Remove product from warehouse array.\n"
              + "6.  Search product in warehouse array.\n"
              + "7.  Display warehouse array.\n"
              + "8.  Save products to file.\n"
              + "9.  Read products from file.\n"
              + "10. Show long warranty electronic products.\n"
              + "11. Open GUI.\n"
              + "12. Exit.\n"
              + ">> ");
    }

    public static void fillList() {
        Supplier s1 = new Supplier("S101", "Tech Supply", "0501112222", "Riyadh");
        Supplier s2 = new Supplier("S202", "Food Market", "0503334444", "Jeddah");

        Product p1 = new ElectronicProduct(101, "Laptop", 3500.0, "ELEC", 5, 2, s1, "HP", 3);
        Product p2 = new ElectronicProduct(102, "Tablet", 1800.0, "ELEC", 4, 2, s1, "Apple", 1);
        Product p3 = new FoodProduct(201, "Milk", 8.5, "FOOD", 20, 5, s2, "12/12/2026", 4.0);
        Product p4 = new FoodProduct(202, "Rice", 30.0, "FOOD", 15, 4, s2, "10/10/2027", 22.0);

        system.addProduct(p1);
        system.addProduct(p2);
        system.addProduct(p3);
        system.addProduct(p4);

        Product[] warehouseProducts = {p1, p2, p3, p4};
        Warehouse w1 = new Warehouse("Main Warehouse", "Riyadh", warehouseProducts);
        system.addWarehouse(w1);
    }

    public static void addProduct() {
        System.out.println("1. Electronic product");
        System.out.println("2. Food product");

        int type = readIntInRange("Choose type: ", 1, 2);
        int itemId = readPositiveInt("Enter item ID: ");
        String itemName = readName("Enter item name: ");
        double unitPrice = readPositiveDouble("Enter unit price: ");
        String categoryCode = readText("Enter category code: ");
        int quantity = readPositiveInt("Enter quantity: ");
        int reorderLevel = readPositiveInt("Enter reorder level: ");

        Supplier supplier = new Supplier("S999", "Default Supplier", "0500000000", "Riyadh");

        if (type == 1) {
            String brand = readName("Enter brand: ");
            int warranty = readPositiveInt("Enter warranty years: ");
            system.addProduct(new ElectronicProduct(itemId, itemName, unitPrice, categoryCode,
                    quantity, reorderLevel, supplier, brand, warranty));
        } else {
            String expiryDate = readDate("Enter expiry date DD/MM/YYYY: ");
            double storageTemp = readPositiveDouble("Enter storage temperature: ");
            system.addProduct(new FoodProduct(itemId, itemName, unitPrice, categoryCode,
                    quantity, reorderLevel, supplier, expiryDate, storageTemp));
        }

        System.out.println("Product added successfully.");
    }

    public static void appendProductToWarehouse() {
        Warehouse warehouse = system.getWarehouses().get(0);
        int id = readPositiveInt("Enter product ID to add: ");
        Product product = system.findProductById(id);

        if (product == null) {
            System.out.println("Product not found.");
            return;
        }

        Product[] oldArray = warehouse.getProducts();
        Product[] newArray = new Product[oldArray.length + 1];

        for (int i = 0; i < oldArray.length; i++) {
            newArray[i] = oldArray[i];
        }

        newArray[newArray.length - 1] = product;
        warehouse.setProducts(newArray);

        System.out.println("Product added to warehouse array.");
    }

    public static void removeProductFromWarehouse() {
        Warehouse warehouse = system.getWarehouses().get(0);
        int id = readPositiveInt("Enter product ID to remove: ");
        Product[] oldArray = warehouse.getProducts();

        int index = -1;
        for (int i = 0; i < oldArray.length; i++) {
            if (oldArray[i] != null && oldArray[i].getItemId() == id) {
                index = i;
            }
        }

        if (index == -1) {
            System.out.println("Product not found in warehouse array.");
            return;
        }

        Product[] newArray = new Product[oldArray.length - 1];

        for (int i = 0, j = 0; i < oldArray.length; i++) {
            if (i != index) {
                newArray[j] = oldArray[i];
                j++;
            }
        }

        warehouse.setProducts(newArray);
        System.out.println("Product removed from warehouse array.");
    }

    public static void searchProductInWarehouse() {
        Warehouse warehouse = system.getWarehouses().get(0);
        String keyword = readText("Enter keyword: ");
        Product[] array = warehouse.getProducts();

        for (int i = 0; i < array.length; i++) {
            if (array[i] != null && array[i].getItemName().toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println(array[i]);
                System.out.println("------------------------------------------");
            }
        }
    }

    public static void displayWarehouseProducts() {
        Warehouse warehouse = system.getWarehouses().get(0);
        Product[] array = warehouse.getProducts();

        for (int i = 0; i < array.length; i++) {
            if (array[i] != null) {
                System.out.println(array[i]);
                System.out.println("------------------------------------------");
            }
        }
    }

    /**
 * Saves all products to the text file.
 */
public static void writeText() {
    try {
        Formatter output = new Formatter("products.txt");

        if (system.getProducts().isEmpty()) {
            System.out.println("No products yet.");
        } else {
            for (Product ele : system.getProducts()) {
                output.format(ele.toString() + "\n");
                output.format("\n---------------------------------------------\n");
            }
            System.out.println("All products saved to the text file products.txt");
        }

        output.close();

    } catch (SecurityException ex) {
        System.err.println("You do not have write access to this file.");
        System.err.println(ex);
    } catch (FileNotFoundException ex) {
        System.err.println("Error opening or creating file.");
        System.err.println(ex);
    }
}

/**
 * Reads the text file line by line and prints each line.
 */
public static void readText() {
    try {
        Scanner fileIn = new Scanner(new File("products.txt"));

        while (fileIn.hasNextLine()) {
            System.out.println(fileIn.nextLine());
        }

        fileIn.close();

    } catch (FileNotFoundException ex) {
        System.err.println("Error opening or creating file.");
        System.err.println(ex);
    } catch (NoSuchElementException ex) {
        System.err.println("File improperly formed.");
        System.err.println(ex);
    } catch (IllegalStateException ex) {
        System.err.println("Error reading from file.");
        System.err.println(ex);
    }
}

    public static void showLongWarrantyProducts() {
        for (int i = 0; i < system.getProducts().size(); i++) {
            Product p = system.getProducts().get(i);

            if (p instanceof ElectronicProduct) {
                ElectronicProduct ep = (ElectronicProduct) p;

                if (ep.hasLongWarranty()) {
                    System.out.println(ep);
                    System.out.println("------------------------------------------");
                }
            }
        }
    }

    public static void openGUI() {
        try {
            GUI.main(null);
        } catch (Exception ex) {
            System.out.println("GUI error: " + ex.getMessage());
        }
    }

    private static int readPositiveInt(String prompt) {
        int value;

        while (true) {
            System.out.print(prompt);
            try {
                value = Integer.parseInt(input.nextLine().trim());
                if (value > 0) {
                    return value;
                }
                System.out.println("Value must be positive");
            } catch (NumberFormatException ex) {
                System.out.println("Enter digits only");
            }
        }
    }

    private static int readIntInRange(String prompt, int min, int max) {
        int value;

        while (true) {
            value = readPositiveInt(prompt);
            if (value >= min && value <= max) {
                return value;
            }
            System.out.println("Value must be between " + min + " and " + max);
        }
    }

    private static double readPositiveDouble(String prompt) {
        double value;

        while (true) {
            System.out.print(prompt);
            try {
                value = Double.parseDouble(input.nextLine().trim());
                if (value > 0) {
                    return value;
                }
                System.out.println("Value must be positive");
            } catch (NumberFormatException ex) {
                System.out.println("Enter a valid number");
            }
        }
    }

    private static String readName(String prompt) {
        String value;

        while (true) {
            System.out.print(prompt);
            value = input.nextLine().trim();

            boolean valid = value.length() >= 2 && value.length() <= 50;

            for (int i = 0; i < value.length(); i++) {
                if (!Character.isLetter(value.charAt(i)) && value.charAt(i) != ' ') {
                    valid = false;
                }
            }

            if (valid) {
                return value;
            }

            System.out.println("English letters and spaces only, length 2-50");
        }
    }

    private static String readText(String prompt) {
        String value;

        while (true) {
            System.out.print(prompt);
            value = input.nextLine().trim();

            if (value.length() > 0) {
                return value;
            }

            System.out.println("Text cannot be empty");
        }
    }

 private static String readDate(String prompt) {
    String date;

    while (true) {
        System.out.print(prompt);
        date = input.nextLine().trim();

        if (date.length() == 10
                && date.charAt(2) == '/'
                && date.charAt(5) == '/') {

            boolean valid = true;

            for (int i = 0; i < date.length(); i++) {

                if (i == 2 || i == 5) {
                    continue;
                }

                if (!Character.isDigit(date.charAt(i))) {
                    valid = false;
                }
            }

            if (valid) {

                int day = Integer.parseInt(date.substring(0, 2));
                int month = Integer.parseInt(date.substring(3, 5));
                int year = Integer.parseInt(date.substring(6, 10));

                int maxDay = 31;

                if (month == 4 || month == 6 || month == 9 || month == 11) {
                    maxDay = 30;
                } else if (month == 2) {
                    maxDay = 28;
                }

                if (year >= 2020
                        && year <= 2030
                        && month >= 1
                        && month <= 12
                        && day >= 1
                        && day <= maxDay) {

                    return date;
                }
            }
        }

        System.out.println("Date must be DD/MM/YYYY with valid values");
    }
}
}