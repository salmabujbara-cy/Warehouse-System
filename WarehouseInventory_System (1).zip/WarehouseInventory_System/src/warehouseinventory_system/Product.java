
package warehouseinventory_system;

// Concrete product class.
public class Product extends Item {

    private int quantity;
    private int reorderLevel;
    private Supplier supplier;

    // empty constructor
    public Product() {
        this(0, "", 0.0, "", 0, 0, null);
    }

    /**
     * Full constructor
     * @param itemId item id
     * @param itemName item name
     * @param unitPrice unit price
     * @param categoryCode category code
     * @param quantity product quantity
     * @param reorderLevel reorder level
     * @param supplier supplier object
     */
    public Product(int itemId, String itemName, double unitPrice, String categoryCode,
                   int quantity, int reorderLevel, Supplier supplier) {
        super(itemId, itemName, unitPrice, categoryCode);
        setQuantity(quantity);
        setReorderLevel(reorderLevel);
        setSupplier(supplier);
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity cannot be negative");
        }
        this.quantity = quantity;
    }

    public int getReorderLevel() {
        return reorderLevel;
    }

    public void setReorderLevel(int reorderLevel) {
        if (reorderLevel < 0) {
            throw new IllegalArgumentException("Reorder level cannot be negative");
        }
        this.reorderLevel = reorderLevel;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    /**
     * Calculates product inventory value.
     * @return unit price multiplied by quantity
     */
    @Override
    public double calculateValue() {
        return getUnitPrice() * getQuantity();
    }

    @Override
    public boolean isAvailable() {
        return getQuantity() > 0;
    }

    @Override
    public void showDetails() {
        System.out.println(toString());
    }

    public boolean needsReorder() {
        return getQuantity() <= getReorderLevel();
    }

    @Override
    public String toString() {
        return String.format("%s%nQuantity: %d%nReorder Level: %d%nAvailable: %b%nNeeds Reorder: %b%nSupplier: %s",
                super.toString(), getQuantity(), getReorderLevel(), isAvailable(), needsReorder(), getSupplier());
    }
}

