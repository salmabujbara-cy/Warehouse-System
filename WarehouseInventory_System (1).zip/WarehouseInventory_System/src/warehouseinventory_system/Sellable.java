

package warehouseinventory_system;

// Interface for sellable items
public interface Sellable {

    public static final double TAX_RATE = 0.15;

    public abstract double calculateValue();

     public abstract boolean isAvailable();
}