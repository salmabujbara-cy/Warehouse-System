
package warehouseinventory_system;

public class Supplier {

    private final String SUPPLIER_ID;
    private String supplierName;
    private String phoneNumber;
    private String city;

    
    private final String SUPPLIER_REF;

    private static int count;

    // empty constructor
    public Supplier() {
        this("", "", "", "");
    }

    /**
     * Full constructor
     * @param SUPPLIER_ID supplier id
     * @param supplierName supplier name
     * @param phoneNumber phone number
     * @param city city
     */
    public Supplier(String SUPPLIER_ID, String supplierName, String phoneNumber, String city) {
        this.SUPPLIER_ID = SUPPLIER_ID;
        setSupplierName(supplierName);
        setPhoneNumber(phoneNumber);
        setCity(city);
        this.SUPPLIER_REF = generateSupplierRef();

        count++;
    }

    public String getSupplierId() {
        return SUPPLIER_ID;
    }

  
    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName.trim();
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city.trim();
    }

    public String getSupplierRef() {
        return SUPPLIER_REF;
    }

  

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Supplier.count = count;
    }

    private String generateSupplierRef() {
        String namePart = "";
        if (supplierName != null && supplierName.length() >= 2) {
            namePart = supplierName.substring(0, 2);
        }

        String idPart = "";
        if (SUPPLIER_ID != null && SUPPLIER_ID.length() >= 2) {
            idPart = SUPPLIER_ID.substring(SUPPLIER_ID.length() - 2);
        }

        return (namePart + idPart).toUpperCase();
    }

    public void displayInfo() {
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return String.format(
                "Supplier ID: %s%nSupplier Ref: %s%nName: %s%nPhone: %s%nCity: %s",
               getSupplierId(),getSupplierRef(), getSupplierName(), getPhoneNumber(), getCity()
        );
    }
}

