package warehouseinventory_system;

public class Warehouse implements Sellable {

    private final int WAREHOUSE_ID;
    private String warehouseName;
    private String location;
    private Product[] products;
    private static int count;

    public Warehouse() {
        this("", "", new Product[0]);
    }

    public Warehouse(String warehouseName, String location,  Product[] products) {
        this.WAREHOUSE_ID = generateId();
        setWarehouseName(warehouseName);
        setLocation(location);
        setProducts(products);
        count++;
    }

    private int generateId() {
        int min = 1000;
        int max = 9999;
        return (int) (Math.random() * (max - min + 1)) + min;
    }

    public int getWarehouseId() {
        return WAREHOUSE_ID;
    }

   

    public String getWarehouseName() {
        return warehouseName;
    }

    public void setWarehouseName(String warehouseName) {
        this.warehouseName = warehouseName.trim();
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location.trim();
    }


    public Product[] getProducts() {
        return products;
    }

    public void setProducts(Product[] products) {
        this.products = products;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Warehouse.count = count;
    }

  @Override
public double calculateValue() {

    double total = 0;

    if (products != null) {

        for (int i = 0; i < products.length; i++) {

            if (products[i] != null) {
                total += products[i].calculateValue();
            }
        }
    }

    return total;
}
    @Override
    public boolean isAvailable() {
        return products != null && products.length > 0;
    }

   public int getTotalQuantity() {

    int total = 0;

    if (products != null) {

        for (int i = 0; i < products.length; i++) {

            if (products[i] != null) {
                total += products[i].getQuantity();
            }
        }
    }

    return total;
}

    public void displayInfo() {
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return String.format(
                "Warehouse ID: %d%nWarehouse Name: %s%nLocation: %s%nProducts Count: %d",
                getWarehouseId(), getWarehouseName(), getLocation(), 
                products == null ? 0 : products.length
        );
    }
}