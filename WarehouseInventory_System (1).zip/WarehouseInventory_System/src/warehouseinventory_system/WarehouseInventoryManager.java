package warehouseinventory_system;

import java.util.ArrayList;

// Manages products and warehouses.
public class WarehouseInventoryManager {

    private ArrayList<Product> products;
    private ArrayList<Warehouse> warehouses;

    // empty constructor
    public WarehouseInventoryManager() {
        products = new ArrayList<Product>();
        warehouses = new ArrayList<Warehouse>();
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public ArrayList<Warehouse> getWarehouses() {
        return warehouses;
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public void removeProduct(Product product) {
        products.remove(product);
    }

    public Product findProductById(int itemId) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getItemId() == itemId) {
                return products.get(i);
            }
        }
        return null;
    }

    public void addWarehouse(Warehouse warehouse) {
        warehouses.add(warehouse);
    }

    public void removeWarehouse(Warehouse warehouse) {
        warehouses.remove(warehouse);
    }

    public Warehouse findWarehouseById(int warehouseId) {
        for (int i = 0; i < warehouses.size(); i++) {
            if (warehouses.get(i).getWarehouseId() == warehouseId) {
                return warehouses.get(i);
            }
        }
        return null;
    }

    public void displayAllProducts() {
        for (int i = 0; i < products.size(); i++) {
            System.out.println(products.get(i));
            System.out.println("------------------------------------------");
        }
    }

    public void displayAllWarehouses() {
        for (int i = 0; i < warehouses.size(); i++) {
            System.out.println(warehouses.get(i));
            System.out.println("------------------------------------------");
        }
    }

    public void displayElectronicProducts() {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i) instanceof ElectronicProduct) {
                System.out.println(products.get(i));
                System.out.println("------------------------------------------");
            }
        }
    }

    public void displayFoodProducts() {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i) instanceof FoodProduct) {
                System.out.println(products.get(i));
                System.out.println("------------------------------------------");
            }
        }
    }

    public void searchProduct(String keyword) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getItemName().toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println(products.get(i));
                System.out.println("------------------------------------------");
            }
        }
    }

    public double calculateInventoryValue() {
        double total = 0;

        for (int i = 0; i < products.size(); i++) {
            total += products.get(i).calculateValue();
        }

        return total;
    }
}
